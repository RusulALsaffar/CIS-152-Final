
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Queue;
import java.util.Random;

public class CallsCounter {
	static double PROCESS = 3;// Math.random() *( 7 -2) + 2;
	static int thetime = 0;
	static int totalpeople = 0;
	final static int MAX_Representative = 150;
	// final static int Num_phonecalls = 8;// limte of customer is 19+1=20
	static int Num_phonecalls;

	/**
	 * @param args Loads a queue with customer with various wait times than process
	 *             the Queue<E>.class process the queue
	 */
	public static void main(String[] args) {

		PROCESS = Math.round(PROCESS);

		long starttime = System.nanoTime();
		// methodToTime();
		long endtime = System.nanoTime();
		long duration = (endtime - starttime);

		int arrived = 0;
		workItem workItem = new workItem(arrived);
		LinkedQueue<workItem> customerQueue = new LinkedQueue<workItem>();

		double[] cashierTime = new double[MAX_Representative];
		List<Integer> lList = new ArrayList<Integer>();
		double totalTime;
		double averageTime, departs;
		int Representative = 0;
//		System.out.println(" Representative Number: " + (Representative));
		// process the simulation for various number of Representative.
		for (Representative = 0; Representative < MAX_Representative; Representative++) { // System.out.println("stime
																							// " + starttime);
			System.out.println(" Representative Number: " + (Representative + 1));
			// initially set each Representative time to zero .
			for (int counta = 0; counta < Representative; counta++)
				cashierTime[counta] = 0;
			// load customer queue.
			// int randomNum = rand.nextInt((max - min) + 1) + min;
			workItem.setcallStart((double) Math.random());
			Random rand = new Random();
			Num_phonecalls = rand.nextInt((50 - 1) + 1) + 1;
			for (int countc = 0; countc <= Num_phonecalls; countc++)
				// System.out.println(" time------ "+ workItem.toString() );
				customerQueue.enqueue(workItem);

			// process all customers in the queue
			while (!customerQueue.isEmpty()) {
				arrived++;
				customerQueue.dequeue();
				for (int ca = 0; ca <= Representative; ca++) {

					int total = 0;

					total = total + ca;

					total++;
					if (!(customerQueue.isEmpty())) {

					}
					// System.out.println("arrive time-- "+ workItem.getArrivalTime());
					if (workItem.getcallStart() > cashierTime[ca])
						departs = workItem.getcallStart() + PROCESS;
					else
						departs = cashierTime[ca] + PROCESS;
					workItem.setcallEnd(departs);
					// System.out.println("depart time-- "+ workItem.getDepartureTime());
					cashierTime[ca] = departs;
					totalTime = +workItem.totalTime();

					averageTime = totalTime / Num_phonecalls;
					DecimalFormat fmt = new DecimalFormat("#.##");
					fmt.format(averageTime);

				}
				Random rand2 = new Random();
				int randtime = rand2.nextInt((360 - 30) + 1) + 30;
				int elaspetime = customerQueue.size() * randtime;
				// totalitems = totalitems + customerQueue.size() ;
				thetime = thetime + elaspetime;
				lList.add(elaspetime);
				// System.out.println("caller Number " + customerQueue.size() + " took "+
				// elaspetime + " seconds");
			}
			Collections.sort(lList);
			for (int i = 0; i < lList.size(); i++) {
				System.out.println("caller Number " + (i + 1) + " took " + lList.get(i) + " seconds");
			}
			totalpeople = totalpeople + arrived;
			// System.out.println(" Representative Number: " + (Representative + 1));
			System.out.println(arrived + " people who called in" + "\n");
			// customerQueue.dequeue();

			// output results for this simulation.
		}
		totalTime = +workItem.totalTime();
		System.out.println(" Number of Representative: " + (MAX_Representative));
		System.out.println(" Total Number of Callers: " + totalpeople);

		System.out.println("Avareg time per call in second " + totalTime + "\n");
		System.out.println("New total in minutes is " + thetime / 3600 + "\n");
		// System.out.println("the total number of calls " + totalitems + "\n");

	}

}
